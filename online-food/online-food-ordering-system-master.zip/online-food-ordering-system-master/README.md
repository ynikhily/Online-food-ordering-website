Online-Food-Ordering
====================

An online portal for connecting 
Restaurants in an area. 
With this system we aim 
to avail food at doorstep of customers with cash on delivery option. 


Database is included in restraunt.sql

1. first import restraunt.sql database in your xamp.
2. then go to index.html for home page of the website.
